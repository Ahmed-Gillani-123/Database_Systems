
--Ahmed Gillani

CREATE DATABASE IF NOT EXISTS bookstore_normalization_lab;
USE bookstore_normalization_lab;

-- Clean start
DROP TABLE IF EXISTS Enrollment;
DROP TABLE IF EXISTS Course;
DROP TABLE IF EXISTS Instructor;
DROP TABLE IF EXISTS Student;



CREATE TABLE Student (
    StudentID VARCHAR(10) PRIMARY KEY,
    StudentName VARCHAR(100) NOT NULL
);

-- The bookstore task is implemented below according to the raw
-- bookstore data in the manual.

DROP TABLE IF EXISTS OrderItem;
DROP TABLE IF EXISTS `Order`;
DROP TABLE IF EXISTS Book;
DROP TABLE IF EXISTS Publisher;
DROP TABLE IF EXISTS Customer;

CREATE TABLE Customer (
    CustID VARCHAR(10) PRIMARY KEY,
    CustName VARCHAR(100) NOT NULL,
    CustEmail VARCHAR(150) NOT NULL
);

CREATE TABLE Publisher (
    PublisherID VARCHAR(10) PRIMARY KEY,
    PublisherName VARCHAR(100) NOT NULL
);

CREATE TABLE Book (
    BookID VARCHAR(10) PRIMARY KEY,
    BookTitle VARCHAR(150) NOT NULL,
    PublisherID VARCHAR(10) NOT NULL,
    UnitPrice DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (PublisherID) REFERENCES Publisher(PublisherID)
);

CREATE TABLE `Order` (
    OrderID VARCHAR(10) PRIMARY KEY,
    OrderDate DATE NOT NULL,
    CustID VARCHAR(10) NOT NULL,
    FOREIGN KEY (CustID) REFERENCES Customer(CustID)
);

CREATE TABLE OrderItem (
    OrderID VARCHAR(10) NOT NULL,
    BookID VARCHAR(10) NOT NULL,
    Qty INT NOT NULL,
    PRIMARY KEY (OrderID, BookID),
    FOREIGN KEY (OrderID) REFERENCES `Order`(OrderID),
    FOREIGN KEY (BookID) REFERENCES Book(BookID)
);



INSERT INTO Customer (CustID, CustName, CustEmail) VALUES
('C-11', 'Bilal', 'bilal@x.com'),
('C-12', 'Areeba', 'areeba@x.com');

INSERT INTO Publisher (PublisherID, PublisherName) VALUES
('PUB-01', 'Pearson'),
('PUB-02', 'OReilly');

INSERT INTO Book (BookID, BookTitle, PublisherID, UnitPrice) VALUES
('B-1', 'SQL Basics', 'PUB-01', 1200),
('B-2', 'Python 101', 'PUB-02', 1500),
('B-3', 'Networks', 'PUB-01', 1800);

INSERT INTO `Order` (OrderID, OrderDate, CustID) VALUES
('O-501', '2026-04-02', 'C-11'),
('O-502', '2026-04-03', 'C-12'),
('O-503', '2026-04-05', 'C-11');

INSERT INTO OrderItem (OrderID, BookID, Qty) VALUES
('O-501', 'B-1', 1),
('O-501', 'B-2', 2),
('O-502', 'B-1', 3),
('O-503', 'B-3', 1),
('O-503', 'B-2', 1);

SHOW TABLES;
DESCRIBE Customer;
DESCRIBE Publisher;
DESCRIBE Book;
DESCRIBE `Order`;
DESCRIBE OrderItem;
